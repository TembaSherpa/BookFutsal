from django.contrib import admin
from .models import Futsal

# Register your models here.
class FutsalAdmin(admin.ModelAdmin):
    list_display = ('username', 'profile_picture')  # Customize based on your model fields
    search_fields = ('username',)