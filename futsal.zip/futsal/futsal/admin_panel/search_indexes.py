# admin_panel/search_indexes.py
from haystack import indexes
from .models import Futsal

class FutsalIndex(indexes.SearchIndex, indexes.Indexable):
    text = indexes.CharField(document=True, use_template=True)

    def get_model(self):
        return Futsal

    def index_queryset(self, using=None):
        return self.get_model().objects.all()
