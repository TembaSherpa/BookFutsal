from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings
from .views import booking_requests, confirm_booking, cancel_booking


urlpatterns = [
    path('dashboard/', views.dashboard, name='dashboard'),
    path('login/', views.user_login, name='login'),
    path('signup/', views.user_signup, name='signup'),
    path('logout', views.handle_logout, name="logout"),
    path('profile/', views.profile_view, name='profile'),
    path('booking_requests/', booking_requests, name='booking_requests'),
    path('confirm_booking/<int:booking_id>/', confirm_booking, name='confirm_booking'),
    path('cancel_booking/<int:booking_id>/', cancel_booking, name='cancel_booking'),
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)