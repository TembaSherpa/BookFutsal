# views.py in admin_panel
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from .forms import SignUpForm, ProfileForm
from .models import Profile, User
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib import messages
from user_panel.models import Booking
from django.contrib.auth.decorators import login_required
from django.utils.timezone import now, timedelta
from datetime import datetime

def handle_logout(request):
    logout(request)
    return redirect("login")

def user_signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # Redirect to login page after successful signup
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            return render(request, 'login.html', {'error_message': 'Invalid username or password'})
    else:
        return render(request, 'login.html')

@login_required
def dashboard(request):
    # Fetch the Profile instance associated with the logged-in User
    profile = get_object_or_404(Profile, user=request.user)  # Correct field usage 'username' to refer to User object
    
    # Fetch confirmed bookings for the timeline
    # Get the current date
    current_date = now().date()
    # Get the search_date from request and ensure it's in the correct format (YYYY-MM-DD)
    search_date_str = request.GET.get('search_date', current_date)

     # Convert the search_date to a proper date object if it's a string
    if isinstance(search_date_str, str):
        try:
            search_date = datetime.strptime(search_date_str, '%Y-%m-%d').date()
        except ValueError:
            # If parsing fails, fall back to the current date
            search_date = current_date
    else:
        # If it's already a date object, just use it
        search_date = search_date_str

    # Check if a search query is provided
    # Get the selected period (daily, weekly, monthly)
    period = request.GET.get('period', 'daily')
    

    # Filter bookings by the provided search date or the current date
    # Filter by period
    if period == 'daily':
        bookings = Booking.objects.filter(profile=profile, date=search_date, is_confirmed=True)
    elif period == 'weekly':
        start_of_week = search_date - timedelta(days=search_date.weekday())
        end_of_week = start_of_week + timedelta(days=6)
        bookings = Booking.objects.filter(profile=profile, date__range=[start_of_week, end_of_week], is_confirmed=True)
    elif period == 'monthly':
        start_of_month = search_date.replace(day=1)
        next_month = (start_of_month + timedelta(days=32)).replace(day=1)
        end_of_month = next_month - timedelta(days=1)
        bookings = Booking.objects.filter(profile=profile, date__range=[start_of_month, end_of_month], is_confirmed=True)
        print(bookings)  # Debugging: This should print queryset of bookings

    # Generate booking statistics
    completed_count = bookings.count()
    pending_count = Booking.objects.filter(profile=profile, is_confirmed=False).count()

    context = {
        'confirmed_bookings': bookings,
        'completed_count': completed_count,
        'pending_count': pending_count,
        'period': period,
        'current_date': current_date,
        'search_date': search_date,  
    }

    return render(request, 'dashboard.html', context)



@login_required
def profile_view(request):
    profile, created = User.objects.get_or_create(username=request.user)

    if request.method == 'POST':
        profile_form = ProfileForm(request.POST, request.FILES, instance=profile)
        password_form = PasswordChangeForm(user=request.user, data=request.POST)

        if 'save_profile' in request.POST and profile_form.is_valid():
            profile_form.save()
            messages.success(request, 'Your profile has been updated!')
            return redirect('profile')

        if 'change_password' in request.POST and password_form.is_valid():
            user = password_form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Your password has been updated!')
            return redirect('profile')

    else:
        profile_form = ProfileForm(instance=profile)
        password_form = PasswordChangeForm(user=request.user)

    context = {
        'profile_form': profile_form,
        'password_form': password_form,
        'profile': profile,
    }

    return render(request, 'profile.html', context)

@login_required
def booking_requests(request):
    profile = get_object_or_404(Profile, user=request.user)
    bookings = Booking.objects.filter(profile=profile)
    return render(request, 'booking_requests.html', {'bookings': bookings})

@login_required
def confirm_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    booking.is_confirmed = True
    booking.save()
    return redirect('dashboard')

@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    booking.delete()
    return redirect('booking_requests')
