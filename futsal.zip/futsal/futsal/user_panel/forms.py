from django import forms
from admin_panel.models import Futsal
from django.core.exceptions import ValidationError
import re
from .models import Booking

class SearchForm(forms.Form):
    query = forms.CharField(label='Search', max_length=100)

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['date', 'time', 'user_info', 'email', 'number', 'payment_method']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'time': forms.TimeInput(attrs={'type': 'time'}),
            'payment_method': forms.Select(choices=[('e_sewa', 'E-sewa'), ('khalti', 'Khalti'), ('bank_transfer', 'Bank Transfer')]),
        }
    def clean(self):
        cleaned_data = super().clean()
        date = cleaned_data.get('date')
        time = cleaned_data.get('time')

        if date and time:
            # Check if there's already a booking with the same date and time
            if Booking.objects.filter(date=date, time=time).exists():
                raise ValidationError("This time slot is already booked. Please choose another time.")

        return cleaned_data