from django.db import models
from admin_panel.models import Profile

# Create your models here.
class Booking(models.Model):
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.CharField(max_length=10)  # e.g., '6:00 AM'
    user_info = models.CharField(max_length=100)
    email = models.EmailField()
    number = models.CharField(max_length=15)
    payment_method = models.CharField(max_length=20)
    is_confirmed = models.BooleanField(default=False)

    def __str__(self):
        return f"Booking for {self.profile.user.username} on {self.date} at {self.time}"