# urls.py
from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from .views import BookFutsalView, available_times, FutsalDetailView

urlpatterns = [
    path('', views.home, name='home'),
    path('search/', views.search, name='search'),
    path('about/', views.about_us, name='about_us'),
    path('events/', views.events_view, name='events_us'),
    path('futsal/<int:id>/', FutsalDetailView.as_view(), name='futsal_detail'),
    path('futsal/<int:profile_id>/book/', BookFutsalView.as_view(), name='book_futsal'),
    path('available-times/', available_times, name='available_times'),
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)