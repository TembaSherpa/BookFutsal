# views.py
from django.shortcuts import render, get_object_or_404, redirect
from admin_panel.models import Profile
from .forms import SearchForm, BookingForm
from haystack.query import SearchQuerySet
from django.views.generic import DetailView
from django.views import View
from django.http import JsonResponse
from django.utils.dateparse import parse_date
from .models import Booking


def home(request):
    return render(request, 'home.html')

def search(request):
    form = SearchForm(request.GET or None)
    query = form.data.get('query')
    results = []
    if query:
        results = Profile.objects.filter(user__username__icontains=query)
    return render(request, 'home.html', {'results': results, 'form': form, 'query': query})

def about_us(request):
    return render(request, 'about_us.html')

def events_view(request):
    return render(request, 'events.html')

class FutsalDetailView(DetailView):
    model = Profile
    template_name = 'futsal_detail.html'
    context_object_name = 'profile'
    
    def get_object(self):
        return get_object_or_404(Profile, id=self.kwargs['id'])
    
def available_times(request):
    date_str = request.GET.get('date')
    selected_date = parse_date(date_str)
    if selected_date:
        # Fetch existing bookings for the date
        existing_bookings = Booking.objects.filter(date=selected_date)
        unavailable_times = [booking.time_slot.strftime('%I:%M %p') for booking in existing_bookings]
        return JsonResponse({'unavailable_times': unavailable_times})
    return JsonResponse({'unavailable_times': []})

class BookFutsalView(View):
    def post(self, request, profile_id):
        form = BookingForm(request.POST)
        if form.is_valid():
            # Retrieve the selected futsal profile
            profile = get_object_or_404(Profile, id=profile_id)
            
            # Create the booking instance
            booking = form.save(commit=False)
            booking.profile = profile

            # Check if the selected date and time is already booked
            selected_date = form.cleaned_data['date']
            time = form.cleaned_data['time']
            if Booking.objects.filter(date=selected_date, time=time, profile=profile).exists():
                form.add_error(None, "The selected date and time slot is already booked.")
                return render(request, 'futsal_detail.html', {'form': form, 'profile': profile})
            
            # Save the booking
            booking.save()
            return redirect('home')  # Redirect to a confirmation page

        return render(request, 'futsal_detail.html', {'form': form, 'profile': get_object_or_404(Profile, id=profile_id)})

    def get(self, request, profile_id):
        form = BookingForm()
        return render(request, 'futsal_detail.html', {'form': form, 'profile': get_object_or_404(Profile, id=profile_id)})