# widgets.py
from django import forms

class TimeSlotSelect(forms.Select):
    def __init__(self, *args, **kwargs):
        self.time_slots = kwargs.pop('time_slots', [])
        super().__init__(*args, **kwargs)

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        context['widget']['choices'] = [(slot, slot) for slot in self.time_slots]
        return context
